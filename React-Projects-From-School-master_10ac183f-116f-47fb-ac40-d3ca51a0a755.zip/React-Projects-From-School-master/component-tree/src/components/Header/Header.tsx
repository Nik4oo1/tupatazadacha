const Header = () => {
  return (
    <header>
      <h1>Component Tree Blog</h1>
    </header>
  );
};

export default Header;