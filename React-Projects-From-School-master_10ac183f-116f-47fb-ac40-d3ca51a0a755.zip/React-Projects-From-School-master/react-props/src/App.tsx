import './App.css'
import Header from './components/Header'

function App() {

  return (
    <>
      <h2>Time to get started!</h2>
      <Header name="Konstantin Kuzmov" className="12b" number={15} />
    </>
  )
}

export default App
