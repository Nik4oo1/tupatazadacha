export interface PropTaskProps {
  name: string;
  className: string;
  number: number;
}