import './App.css'
import Button from './components/Button'

function App() {
  return (
    <>
      <Button>Button 1</Button>
      <Button>Button 2</Button>
    </>
  )
}

export default App
