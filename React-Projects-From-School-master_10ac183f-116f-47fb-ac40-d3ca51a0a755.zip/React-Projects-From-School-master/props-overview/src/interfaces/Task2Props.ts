export interface Task2Props {
  firstName: string;
  lastName: string;
  title: string;
  image?: string;
  children: React.ReactNode;
}
