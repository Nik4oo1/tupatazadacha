import './App.css'
import reactImage from './assets/IMG_20250828_120348.jpg'

function App() {
  return (
    <img src={reactImage} alt="React"/>
  )
}

export default App